from pathlib import Path
import re


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"{label}: expected one match, found {count}")
    return text.replace(old, new, 1)


def regex_once(text: str, pattern: str, repl: str, label: str, flags: int = 0) -> str:
    updated, count = re.subn(pattern, repl, text, count=1, flags=flags)
    if count != 1:
        raise SystemExit(f"{label}: expected one match, found {count}")
    return updated


def update_updater(path: Path) -> None:
    text = path.read_text()

    text = replace_once(
        text,
        "CHECK_INTERVAL=86400\n\nCOMMAND=check\n",
        "CHECK_INTERVAL=86400\nAUTO_OPERATION_TIMEOUT=900\n\nCOMMAND=check\n",
        f"{path}: auto timeout constant",
    )
    text = replace_once(
        text,
        "PENDING_PREVIOUS_PAYLOAD_TMP=\nfail() {\n",
        "PENDING_PREVIOUS_PAYLOAD_TMP=\nOPERATION_TIMEOUT=${TRACEKNOT_UPDATE_OPERATION_TIMEOUT:-}\nREQUESTED_DEADLINE=${TRACEKNOT_UPDATE_DEADLINE_EPOCH:-0}\nOPERATION_DEADLINE=0\nAUTO_WAITING_FOR_ADOPTION=0\nMANUAL_ADOPTION=0\nfail() {\n",
        f"{path}: operation state",
    )
    text = replace_once(
        text,
        "shell_quote() {\n    printf \"'%s'\" \"$(printf '%s' \"$1\" | sed \"s/'/'\\\\\\\\''/g\")\"\n}\n\nwhile [ \"$#\" -gt 0 ]; do\n",
        """shell_quote() {
    printf \"'%s'\" \"$(printf '%s' \"$1\" | sed \"s/'/'\\\\\\\\''/g\")\"
}

remaining_operation_seconds() {
    if [ \"$OPERATION_TIMEOUT\" -eq 0 ]; then
        printf '%s\\n' 0
        return 0
    fi
    deadline_now=$(date -u '+%s') || return 1
    deadline_remaining=$((OPERATION_DEADLINE - deadline_now))
    [ \"$deadline_remaining\" -gt 0 ] || return 1
    printf '%s\\n' \"$deadline_remaining\"
}

signal_process_tree() {
    signal_name=$1
    process_pid=$2
    if command -v pgrep >/dev/null 2>&1; then
        for child_pid in $(pgrep -P \"$process_pid\" 2>/dev/null || true); do
            signal_process_tree \"$signal_name\" \"$child_pid\"
        done
    fi
    kill -s \"$signal_name\" \"$process_pid\" 2>/dev/null || true
}

run_with_deadline() {
    if [ \"$OPERATION_TIMEOUT\" -eq 0 ]; then
        \"$@\"
        return
    fi
    remaining=$(remaining_operation_seconds) || return 124
    \"$@\" &
    bounded_pid=$!
    (
        while kill -0 \"$bounded_pid\" 2>/dev/null; do
            bounded_now=$(date -u '+%s') || exit 0
            if [ \"$bounded_now\" -ge \"$OPERATION_DEADLINE\" ]; then
                signal_process_tree TERM \"$bounded_pid\"
                sleep 2
                signal_process_tree KILL \"$bounded_pid\"
                exit 0
            fi
            sleep 1
        done
    ) >/dev/null 2>&1 &
    bounded_watchdog=$!
    bounded_status=0
    if wait \"$bounded_pid\"; then
        :
    else
        bounded_status=$?
    fi
    kill \"$bounded_watchdog\" 2>/dev/null || true
    wait \"$bounded_watchdog\" 2>/dev/null || true
    if [ \"$bounded_status\" -ne 0 ]; then
        bounded_now=$(date -u '+%s' 2>/dev/null || printf '%s' \"$OPERATION_DEADLINE\")
        if [ \"$bounded_now\" -ge \"$OPERATION_DEADLINE\" ]; then
            return 124
        fi
    fi
    return \"$bounded_status\"
}

durable_sync() {
    run_with_deadline sync || fail 'filesystem sync exceeded the operation deadline'
}

while [ \"$#\" -gt 0 ]; do
""",
        f"{path}: deadline helpers",
    )
    text = replace_once(
        text,
        "done\n\n[ -n \"${HOME:-}\" ] || fail 'HOME is required'\n",
        """done

if [ -z \"$OPERATION_TIMEOUT\" ]; then
    if [ \"$AUTO_INVOCATION\" -eq 1 ]; then
        OPERATION_TIMEOUT=$AUTO_OPERATION_TIMEOUT
    else
        OPERATION_TIMEOUT=0
    fi
fi
case \"$OPERATION_TIMEOUT\" in ''|*[!0-9]*) fail 'invalid operation timeout' ;; esac
case \"$REQUESTED_DEADLINE\" in ''|*[!0-9]*) fail 'invalid absolute operation deadline' ;; esac
operation_now=$(date -u '+%s') || fail 'cannot establish the operation deadline'
if [ \"$OPERATION_TIMEOUT\" -gt 0 ]; then
    OPERATION_DEADLINE=$((operation_now + OPERATION_TIMEOUT))
fi
if [ \"$REQUESTED_DEADLINE\" -gt 0 ]; then
    [ \"$REQUESTED_DEADLINE\" -gt \"$operation_now\" ] || fail 'absolute operation deadline has already elapsed'
    if [ \"$OPERATION_DEADLINE\" -eq 0 ] || [ \"$REQUESTED_DEADLINE\" -lt \"$OPERATION_DEADLINE\" ]; then
        OPERATION_DEADLINE=$REQUESTED_DEADLINE
    fi
    OPERATION_TIMEOUT=$((OPERATION_DEADLINE - operation_now))
fi
if [ \"$OPERATION_TIMEOUT\" -gt 0 ]; then
    command -v pgrep >/dev/null 2>&1 || fail 'pgrep is required for bounded update execution'
fi

[ -n \"${HOME:-}\" ] || fail 'HOME is required'
""",
        f"{path}: timeout initialization",
    )

    # Make every durability flush obey the same absolute operation deadline.
    text = re.sub(r"(?m)^(\s*)sync$", r"\1durable_sync", text)

    text = replace_once(
        text,
        """        raw_command="$raw_command $(shell_quote "$updater") --global --auto"
    else
        raw_command="cd $(shell_quote "$PROJECT_ROOT") && HOME=$(shell_quote "$HOME") PATH=$(shell_quote "${PATH:-/usr/bin:/bin}") $(shell_quote "$updater") --project $(shell_quote "$PROJECT_ROOT") --auto"
""",
        """        raw_command="$raw_command TRACEKNOT_UPDATE_OPERATION_TIMEOUT=$AUTO_OPERATION_TIMEOUT $(shell_quote "$updater") --global --auto"
    else
        raw_command="cd $(shell_quote "$PROJECT_ROOT") && HOME=$(shell_quote "$HOME") PATH=$(shell_quote "${PATH:-/usr/bin:/bin}") TRACEKNOT_UPDATE_OPERATION_TIMEOUT=$AUTO_OPERATION_TIMEOUT $(shell_quote "$updater") --project $(shell_quote "$PROJECT_ROOT") --auto"
""",
        f"{path}: bounded cron command",
    )

    text = text.replace(
        '"previousLockEntrySha256","previousSourceCommit","registration"',
        '"previousLockEntrySha256","previousSourceRef","registration"',
    )
    text = replace_once(
        text,
        "      and (.previousSourceCommit | test(\"^[0-9a-f]{40}$\"))\n",
        "      and (.previousSourceRef | type == \"string\")\n",
        f"{path}: pending previous ref schema",
    )
    text = replace_once(
        text,
        "    PENDING_PREVIOUS_SOURCE_COMMIT=$(jq -r .previousSourceCommit \"$PENDING_STATE\")\n",
        "    PENDING_PREVIOUS_SOURCE_REF=$(jq -r .previousSourceRef \"$PENDING_STATE\")\n",
        f"{path}: pending previous ref read",
    )
    text = text.replace("pending_previous_source_commit=$6", "pending_previous_source_ref=$6")
    text = text.replace(
        '--arg previousSourceCommit "$pending_previous_source_commit"',
        '--arg previousSourceRef "$pending_previous_source_ref"',
    )
    text = text.replace(
        'previousSourceCommit:$previousSourceCommit',
        'previousSourceRef:$previousSourceRef',
    )
    text = text.replace("$PENDING_PREVIOUS_SOURCE_COMMIT", "$PENDING_PREVIOUS_SOURCE_REF")

    old_lock = """validate_skills_lock() {
    [ -f "$LOCK_FILE" ] && [ ! -L "$LOCK_FILE" ] ||
        fail "Skills CLI lock file is missing or unsafe: $LOCK_FILE"
    jq -e '
      .skills.traceknot.source == "Jin-Doh/traceknot"
      and .skills.traceknot.sourceType == "github"
      and .skills.traceknot.skillPath == "skill/SKILL.md"
    ' "$LOCK_FILE" >/dev/null ||
        fail 'installed Traceknot registration is not owned by the expected Skills CLI source'
    LOCK_REF=$(jq -r '.skills.traceknot.ref // empty' "$LOCK_FILE")
    case "$LOCK_REF" in
        ''|*[!0-9a-f]*) fail 'Skills CLI lock ref must be a 40-character commit' ;;
    esac
    [ "${#LOCK_REF}" -eq 40 ] || fail 'Skills CLI lock ref must be a 40-character commit'
    LOCK_ENTRY_SHA256=$(jq -cS '.skills.traceknot' "$LOCK_FILE" | sha256_stdin)
    [ "${#LOCK_ENTRY_SHA256}" -eq 64 ] || fail 'cannot hash the Skills CLI lock entry'
    if [ -f "$ACTIVE_STATE" ]; then
        ACTIVE_SOURCE_COMMIT=$(jq -r .sourceCommit "$ACTIVE_STATE")
        ACTIVE_LOCK_ENTRY_SHA256=$(jq -r .lockEntrySha256 "$ACTIVE_STATE")
        if [ "$LOCK_REF" != "$ACTIVE_SOURCE_COMMIT" ]; then
            [ -f "$PENDING_STATE" ] && [ "$LOCK_REF" = "$PENDING_SOURCE_COMMIT" ] ||
                fail 'Skills CLI lock changed outside the managed update state; refusing to overwrite it'
        fi
        if [ "$LOCK_ENTRY_SHA256" != "$ACTIVE_LOCK_ENTRY_SHA256" ]; then
            [ -f "$PENDING_STATE" ] && [ "$LOCK_REF" = "$PENDING_SOURCE_COMMIT" ] ||
                fail 'Skills CLI lock metadata changed outside the managed update state; refusing to overwrite it'
        fi
    elif [ "$ADOPTED_AT" -ne 0 ] &&
         [ "$LOCK_ENTRY_SHA256" != "$ADOPTED_LOCK_SHA256" ]; then
        [ -f "$PENDING_STATE" ] && [ "$LOCK_REF" = "$PENDING_SOURCE_COMMIT" ] ||
            fail 'unmanaged Skills CLI lock changed after adoption; refusing to select an automatic baseline'
    fi
}
"""
    new_lock = """validate_skills_lock() {
    [ -f "$LOCK_FILE" ] && [ ! -L "$LOCK_FILE" ] ||
        fail "Skills CLI lock file is missing or unsafe: $LOCK_FILE"
    jq -e '
      (.skills.traceknot.source | ascii_downcase) == "jin-doh/traceknot"
      and .skills.traceknot.sourceType == "github"
      and .skills.traceknot.skillPath == "skill/SKILL.md"
    ' "$LOCK_FILE" >/dev/null ||
        fail 'installed Traceknot registration is not owned by the expected Skills CLI source'
    LOCK_REF=$(jq -r '.skills.traceknot.ref // ""' "$LOCK_FILE")
    LOCK_REF_IS_COMMIT=0
    case "$LOCK_REF" in
        ''|*[!0-9a-f]*) ;;
        *) [ "${#LOCK_REF}" -eq 40 ] && LOCK_REF_IS_COMMIT=1 ;;
    esac
    LOCK_ENTRY_SHA256=$(jq -cS '.skills.traceknot' "$LOCK_FILE" | sha256_stdin)
    [ "${#LOCK_ENTRY_SHA256}" -eq 64 ] || fail 'cannot hash the Skills CLI lock entry'
    if [ -f "$ACTIVE_STATE" ]; then
        [ "$LOCK_REF_IS_COMMIT" -eq 1 ] ||
            fail 'managed Skills CLI lock ref must be the recorded 40-character commit'
        ACTIVE_SOURCE_COMMIT=$(jq -r .sourceCommit "$ACTIVE_STATE")
        ACTIVE_LOCK_ENTRY_SHA256=$(jq -r .lockEntrySha256 "$ACTIVE_STATE")
        if [ "$LOCK_REF" != "$ACTIVE_SOURCE_COMMIT" ]; then
            [ -f "$PENDING_STATE" ] && [ "$LOCK_REF" = "$PENDING_SOURCE_COMMIT" ] ||
                fail 'Skills CLI lock changed outside the managed update state; refusing to overwrite it'
        fi
        if [ "$LOCK_ENTRY_SHA256" != "$ACTIVE_LOCK_ENTRY_SHA256" ]; then
            [ -f "$PENDING_STATE" ] && [ "$LOCK_REF" = "$PENDING_SOURCE_COMMIT" ] ||
                fail 'Skills CLI lock metadata changed outside the managed update state; refusing to overwrite it'
        fi
    elif [ "$ADOPTED_AT" -ne 0 ] &&
         [ "$LOCK_ENTRY_SHA256" != "$ADOPTED_LOCK_SHA256" ]; then
        [ -f "$PENDING_STATE" ] && [ "$LOCK_REF" = "$PENDING_SOURCE_COMMIT" ] ||
            fail 'unmanaged Skills CLI lock changed after adoption; refusing to select an automatic baseline'
    fi
}
"""
    text = replace_once(text, old_lock, new_lock, f"{path}: lock compatibility")

    marker = """    validate_skills_lock
    reconcile_pending_state
fi

if [ "$COMMAND" = enable ]; then
"""
    replacement = """    validate_skills_lock
    reconcile_pending_state
fi

if [ "$AUTO_INVOCATION" -eq 1 ] && [ ! -f "$ACTIVE_STATE" ]; then
    AUTO_WAITING_FOR_ADOPTION=1
    COMMAND=check
fi
if [ "$COMMAND" = apply ] && [ "$AUTO_INVOCATION" -eq 0 ] && [ ! -f "$ACTIVE_STATE" ]; then
    MANUAL_ADOPTION=1
fi

if [ "$COMMAND" = enable ]; then
"""
    text = replace_once(text, marker, replacement, f"{path}: adoption mode")
    text = text.replace("for dependency in crontab curl jq gh tar diff npx sync; do", "for dependency in crontab curl jq gh tar diff npx sync pgrep; do")

    text = replace_once(
        text,
        """if [ "$COMMAND" = status ]; then
    printf 'scope=%s\\nprojectRoot=%s\\nregistration=%s\\nautomatic=%s\\nlastCheck=%s\\nadoptedAt=%s\\n' \\
        "$SCOPE" "$PROJECT_ROOT" "$REGISTRATION" "$AUTOMATIC" "$LAST_CHECK" "$ADOPTED_AT"
""",
        """if [ "$COMMAND" = status ]; then
    printf 'scope=%s\\nprojectRoot=%s\\nregistration=%s\\nautomatic=%s\\nlastCheck=%s\\nadoptedAt=%s\\noperationTimeout=%s\\n' \\
        "$SCOPE" "$PROJECT_ROOT" "$REGISTRATION" "$AUTOMATIC" "$LAST_CHECK" "$ADOPTED_AT" "$OPERATION_TIMEOUT"
""",
        f"{path}: status timeout",
    )

    text = replace_once(
        text,
        """curl_authorization=
if [ -n "${GH_TOKEN:-}" ]; then
    curl_authorization="Authorization: Bearer $GH_TOKEN"
fi

fetch_release_page() {
""",
        """curl_authorization=
if [ -n "${GH_TOKEN:-}" ]; then
    curl_authorization="Authorization: Bearer $GH_TOKEN"
fi
curl_with_deadline() {
    if [ "$OPERATION_TIMEOUT" -eq 0 ]; then
        curl "$@"
        return
    fi
    curl_remaining=$(remaining_operation_seconds) || return 124
    curl_connect_timeout=$curl_remaining
    [ "$curl_connect_timeout" -le 10 ] || curl_connect_timeout=10
    run_with_deadline curl --connect-timeout "$curl_connect_timeout" --max-time "$curl_remaining" "$@"
}

fetch_release_page() {
""",
        f"{path}: curl deadline wrapper",
    )
    text = text.replace("        curl --proto '=https'", "        curl_with_deadline --proto '=https'")

    text = replace_once(
        text,
        """    PRE_ADOPTION_CANDIDATE=0
    if [ ! -f "$ACTIVE_STATE" ] && [ "$RELEASE_EPOCH" -le "$ADOPTED_AT" ]; then
        PRE_ADOPTION_CANDIDATE=1
    else
        POST_ADOPTION_CANDIDATE=1
    fi
""",
        """    PRE_ADOPTION_CANDIDATE=0
    if [ ! -f "$ACTIVE_STATE" ] && [ "$RELEASE_EPOCH" -le "$ADOPTED_AT" ]; then
        PRE_ADOPTION_CANDIDATE=1
    else
        POST_ADOPTION_CANDIDATE=1
    fi
""",
        f"{path}: pre-adoption anchor",
    )
    text = replace_once(
        text,
        """    if [ "$PRE_ADOPTION_CANDIDATE" -eq 1 ]; then
        continue
    fi

    MANIFEST_SHA=$(sha256_file "$MANIFEST")
""",
        """    if [ "$PRE_ADOPTION_CANDIDATE" -eq 1 ] && [ "$MANUAL_ADOPTION" -eq 0 ]; then
        continue
    fi
    POST_ADOPTION_CANDIDATE=1

    MANIFEST_SHA=$(sha256_file "$MANIFEST")
""",
        f"{path}: manual adoption candidates",
    )
    text = replace_once(
        text,
        'if [ "$POST_ADOPTION_CANDIDATE" -eq 0 ] && [ ! -f "$ACTIVE_STATE" ]; then\n',
        'if [ "$POST_ADOPTION_CANDIDATE" -eq 0 ] && [ ! -f "$ACTIVE_STATE" ] && [ "$MANUAL_ADOPTION" -eq 0 ]; then\n',
        f"{path}: baseline no-candidate guard",
    )
    text = replace_once(
        text,
        """printf 'Eligible update: %s (%s)\\n' "$RELEASE_TAG" "$ARTIFACT_SHA"
[ "$COMMAND" = apply ] || exit 0
""",
        """printf 'Eligible update: %s (%s)\\n' "$RELEASE_TAG" "$ARTIFACT_SHA"
if [ "$AUTO_WAITING_FOR_ADOPTION" -eq 1 ]; then
    if [ "$SCOPE" = global ]; then
        adoption_scope=--global
    else
        adoption_scope="--project $(shell_quote "$PROJECT_ROOT")"
    fi
    printf 'Automatic application is waiting for one-time manual adoption: %s apply %s\\n' "$PROGRAM" "$adoption_scope"
    exit 0
fi
[ "$COMMAND" = apply ] || exit 0
""",
        f"{path}: auto adoption guard",
    )

    text = text.replace("gh attestation verify \"$ARCHIVE\"", "run_with_deadline gh attestation verify \"$ARCHIVE\"")
    text = text.replace("        npx --yes \"skills@$SKILLS_CLI_VERSION\" add", "        run_with_deadline npx --yes \"skills@$SKILLS_CLI_VERSION\" add")
    text = text.replace("            npx --yes \"skills@$SKILLS_CLI_VERSION\" add", "            run_with_deadline npx --yes \"skills@$SKILLS_CLI_VERSION\" add")
    text = text.replace("    if ! npx --yes \"skills@$SKILLS_CLI_VERSION\" add", "    if ! run_with_deadline npx --yes \"skills@$SKILLS_CLI_VERSION\" add")
    text = text.replace("        HOME=$HOME npx --yes \"skills@$SKILLS_CLI_VERSION\" add", "        HOME=$HOME run_with_deadline npx --yes \"skills@$SKILLS_CLI_VERSION\" add")

    text = replace_once(
        text,
        """jq -e --arg commit "$SOURCE_COMMIT" '
  .skills.traceknot.source == "Jin-Doh/traceknot"
  and .skills.traceknot.sourceType == "github"
""",
        """jq -e --arg commit "$SOURCE_COMMIT" '
  (.skills.traceknot.source | ascii_downcase) == "jin-doh/traceknot"
  and .skills.traceknot.sourceType == "github"
""",
        f"{path}: post-install source casing",
    )

    # Ensure no accidental direct long-running subprocesses remain in the key network/apply paths.
    if "\n        curl --proto '=https'" in text or "\n    gh attestation verify" in text:
        raise SystemExit(f"{path}: unbounded network/provenance command remained")

    path.write_text(text)


def update_tests(path: Path) -> None:
    text = path.read_text()
    text = replace_once(
        text,
        """        -H) shift 2 ;;
        --proto|--proto-redir) shift 2 ;;
        --tlsv1.2|--fail|--silent|--show-error|--location) shift ;;
""",
        """        -H) shift 2 ;;
        --proto|--proto-redir|--connect-timeout|--max-time) shift 2 ;;
        --tlsv1.2|--fail|--silent|--show-error|--location) shift ;;
""",
        "tests: fake curl timeout args",
    )
    text = replace_once(
        text,
        """if [ -n "$headers" ]; then
    printf 'HTTP/2 200\\r\\ndate: %s\\r\\n\\r\\n' "$FAKE_HTTP_DATE" > "$headers"
fi
""",
        """if [ -n "${FAKE_CURL_SLEEP:-}" ]; then
    sleep "$FAKE_CURL_SLEEP"
fi
if [ -n "$headers" ]; then
    printf 'HTTP/2 200\\r\\ndate: %s\\r\\n\\r\\n' "$FAKE_HTTP_DATE" > "$headers"
fi
""",
        "tests: fake curl sleep",
    )
    text = replace_once(
        text,
        """write_initial_lock() {
    lock=$1
    mkdir -p "$(dirname "$lock")"
    jq -n '{version:1,skills:{traceknot:{source:"Jin-Doh/traceknot",sourceType:"github",ref:"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",skillPath:"skill/SKILL.md",computedHash:"initial"}}}' > "$lock"
}

manifest_sha() {
""",
        """write_initial_lock() {
    lock=$1
    mkdir -p "$(dirname "$lock")"
    jq -n '{version:1,skills:{traceknot:{source:"Jin-Doh/traceknot",sourceType:"github",ref:"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",skillPath:"skill/SKILL.md",computedHash:"initial"}}}' > "$lock"
}
write_unmanaged_lock() {
    lock=$1
    source=$2
    ref=${3-}
    mkdir -p "$(dirname "$lock")"
    if [ -n "$ref" ]; then
        jq -n --arg source "$source" --arg ref "$ref" '{version:1,skills:{traceknot:{source:$source,sourceType:"github",ref:$ref,skillPath:"skill/SKILL.md",computedHash:"initial"}}}' > "$lock"
    else
        jq -n --arg source "$source" '{version:1,skills:{traceknot:{source:$source,sourceType:"github",skillPath:"skill/SKILL.md",computedHash:"initial"}}}' > "$lock"
    fi
}

manifest_sha() {
""",
        "tests: unmanaged lock helper",
    )

    anchor = """# A fresh unmanaged registration adopts its current lock as a no-downgrade baseline.
BASELINE_PROJECT="$TMP_DIR/baseline project"
"""
    new = """# Canonical Skills locks may omit ref, retain a symbolic ref, and preserve source casing.
for lock_ref in '' main; do
    COMPAT_PROJECT="$TMP_DIR/compat-${lock_ref:-none}"
    mkdir -p "$COMPAT_PROJECT"
    COMPAT_SKILL=$COMPAT_PROJECT/.agents/skills/traceknot
    install_initial_skill "$COMPAT_SKILL"
    write_unmanaged_lock "$COMPAT_PROJECT/skills-lock.json" 'jin-doh/traceknot' "$lock_ref"
    "$COMPAT_SKILL/bin/traceknot-skills-update" status --project "$COMPAT_PROJECT" >/dev/null
    "$COMPAT_SKILL/bin/traceknot-skills-update" check --project "$COMPAT_PROJECT" >/dev/null
done

# A fresh unmanaged registration adopts its current lock as a no-downgrade baseline.
BASELINE_PROJECT="$TMP_DIR/baseline project"
"""
    text = replace_once(text, anchor, new, "tests: lock compatibility cases")

    # Add explicit manual-adoption and pre-adoption auto guard after baseline drift restoration.
    anchor2 = """mv "$TMP_DIR/baseline-lock.saved" "$BASELINE_PROJECT/skills-lock.json"

# Global registration: opt-in scheduling, strict seven-day boundary, exact-commit apply.
"""
    new2 = """mv "$TMP_DIR/baseline-lock.saved" "$BASELINE_PROJECT/skills-lock.json"

# Unmanaged scheduled execution may observe, but only explicit apply may adopt a pre-baseline release.
ADOPTION_PROJECT="$TMP_DIR/manual adoption project"
mkdir -p "$ADOPTION_PROJECT"
ADOPTION_SKILL=$ADOPTION_PROJECT/.agents/skills/traceknot
install_initial_skill "$ADOPTION_SKILL"
write_unmanaged_lock "$ADOPTION_PROJECT/skills-lock.json" 'jin-doh/traceknot'
ADOPTION_STATE=$ADOPTION_PROJECT/.agents/.traceknot-update
seed_adoption "$ADOPTION_STATE" "$ADOPTION_PROJECT/skills-lock.json" 1 "$FAKE_NOW"
printf '%s\\t%s\\t%s\\t%s\\n' "$(manifest_sha)" "$((FAKE_NOW - 604801))" "$TAG" "$ARTIFACT_SHA" > "$ADOPTION_STATE/observations.tsv"
before_adoption=$(cat "$NPX_COUNT")
auto_adoption_output=$("$ADOPTION_SKILL/bin/traceknot-skills-update" --project "$ADOPTION_PROJECT" --auto)
printf '%s\\n' "$auto_adoption_output" | grep -F 'waiting for one-time manual adoption' >/dev/null
test "$(cat "$NPX_COUNT")" -eq "$before_adoption"
"$ADOPTION_SKILL/bin/traceknot-skills-update" apply --project "$ADOPTION_PROJECT" >/dev/null
test "$(cat "$NPX_COUNT")" -eq $((before_adoption + 2))
jq -e '.version == "1.2.3"' "$ADOPTION_STATE/active.json" >/dev/null

# The scheduled path has a finite end-to-end operation deadline.
TIMEOUT_PROJECT="$TMP_DIR/timeout project"
mkdir -p "$TIMEOUT_PROJECT"
TIMEOUT_SKILL=$TIMEOUT_PROJECT/.agents/skills/traceknot
install_initial_skill "$TIMEOUT_SKILL"
write_unmanaged_lock "$TIMEOUT_PROJECT/skills-lock.json" 'jin-doh/traceknot' main
TIMEOUT_STATE=$TIMEOUT_PROJECT/.agents/.traceknot-update
seed_adoption "$TIMEOUT_STATE" "$TIMEOUT_PROJECT/skills-lock.json" 1 "$((FAKE_NOW - 1814400))"
START_TIMEOUT=$(date -u '+%s')
if FAKE_CURL_SLEEP=10 TRACEKNOT_UPDATE_OPERATION_TIMEOUT=2 \
    "$TIMEOUT_SKILL/bin/traceknot-skills-update" --project "$TIMEOUT_PROJECT" --auto >/dev/null 2>&1; then
    printf '%s\\n' 'bounded automatic check unexpectedly succeeded' >&2
    exit 1
fi
END_TIMEOUT=$(date -u '+%s')
[ "$((END_TIMEOUT - START_TIMEOUT))" -lt 6 ]
test ! -e "$TIMEOUT_STATE/update.lock"

# Global registration: opt-in scheduling, strict seven-day boundary, exact-commit apply.
"""
    text = replace_once(text, anchor2, new2, "tests: adoption and timeout cases")

    text = replace_once(
        text,
        "grep -F -- \"--global --auto\" \"$CRONTAB_FILE\" >/dev/null\n",
        "grep -F -- \"--global --auto\" \"$CRONTAB_FILE\" >/dev/null\ngrep -F 'TRACEKNOT_UPDATE_OPERATION_TIMEOUT=900' \"$CRONTAB_FILE\" >/dev/null\n",
        "tests: bounded cron assertion",
    )
    path.write_text(text)


def update_docs(path: Path) -> None:
    text = path.read_text()
    text = replace_once(
        text,
        """The updater rejects a scope that does not match the executable's installed Skill root. A global updater cannot update an arbitrary project installation, and a project-local updater cannot update another project. It also requires the Skills CLI lock entry to identify `Jin-Doh/traceknot`, the GitHub source type, and `skill/SKILL.md`.
""",
        """The updater rejects a scope that does not match the executable's installed Skill root. A global updater cannot update an arbitrary project installation, and a project-local updater cannot update another project. It requires the Skills CLI lock entry to identify the `Jin-Doh/traceknot` repository case-insensitively, the GitHub source type, and `skill/SKILL.md`. An unmanaged lock may omit `ref` or retain a branch or tag because those are normal Skills CLI installation forms. After the first verified application, the managed lock must bind the exact 40-character source commit.
""",
        "docs: lock compatibility",
    )
    text = replace_once(
        text,
        """The first trusted check of an unmanaged installation records an adoption baseline consisting of GitHub server time and the canonical SHA-256 digest of the current Traceknot lock entry. A release published at or before that baseline is never selected automatically. This prevents a default-branch installation that is newer than the latest seven-day-old release from being downgraded during the first managed update. Before the first managed application, any lock-entry change invalidates the baseline. After a managed application, the complete lock-entry digest and exact source commit are stored in `active.json`; either changing externally blocks further managed updates rather than overwriting the user's choice.
""",
        """The first trusted check of an unmanaged installation records an adoption baseline consisting of GitHub server time and the canonical SHA-256 digest of the current Traceknot lock entry. A release published at or before that baseline is never selected by an unattended invocation. This prevents a default-branch installation that is newer than the latest seven-day-old release from being downgraded automatically. A user may explicitly run `apply` to adopt the highest eligible verified release even when it predates the baseline; only a successful explicit application creates `active.json` and enables later unattended application. Before that first managed application, any lock-entry change invalidates the baseline. After it, the complete lock-entry digest and exact source commit are stored in `active.json`; either changing externally blocks further managed updates rather than overwriting the user's choice.
""",
        "docs: manual adoption semantics",
    )
    text = replace_once(
        text,
        """When multiple releases are eligible, the highest semantic version is selected. Automatic downgrade is rejected both before and after the first managed application: pre-adoption releases are excluded for unmanaged installations, and lower semantic versions are excluded after `active.json` exists. Reusing an installed semantic version with a different artifact digest is treated as a security failure.
""",
        """When multiple releases are eligible, the highest semantic version is selected. Unattended downgrade is rejected both before and after the first managed application: pre-adoption releases are excluded until the user explicitly adopts a verified release, and lower semantic versions are excluded after `active.json` exists. Reusing an installed semantic version with a different artifact digest is treated as a security failure.
""",
        "docs: downgrade semantics",
    )
    text = replace_once(
        text,
        """3. resolve the highest eligible release published after that baseline;
""",
        """3. resolve the highest eligible release published after that baseline, or the highest eligible release overall for an explicit first `apply`;
""",
        "docs: application sequence",
    )
    text = replace_once(
        text,
        """`disable` removes only the matching marked entry and persists `automatic=0`. Existing unrelated cron entries are retained. Scheduled output is redirected because failures are fail-closed and do not modify the active release record.
""",
        """`disable` removes only the matching marked entry and persists `automatic=0`. Existing unrelated cron entries are retained. Scheduled output is redirected because failures are fail-closed and do not modify the active release record. Every `--auto` invocation receives a 900-second absolute operation deadline by default. Release requests use the remaining budget for connection and transfer timeouts, and provenance, Skills CLI, and durability subprocesses are terminated when the same deadline expires. `TRACEKNOT_UPDATE_OPERATION_TIMEOUT` may set another positive duration for controlled environments, while `TRACEKNOT_UPDATE_DEADLINE_EPOCH` lets a parent process impose an earlier absolute UTC deadline shared across sequential requests and subprocesses.
""",
        "docs: scheduled deadline",
    )
    text = replace_once(
        text,
        """Automatic scheduling also requires:

```text
crontab
```
""",
        """Automatic scheduling also requires:

```text
crontab pgrep
```
""",
        "docs: pgrep dependency",
    )
    text = replace_once(
        text,
        """Use `status` to inspect scope, schedule policy, last trusted check, adoption time, and the last release successfully applied by this updater. `version=unmanaged` means the current registration has only an adoption baseline or was installed outside the bridge's active-state history; it does not mean the Skill is invalid. The first trusted `check` or `apply` records that baseline and deliberately does not apply releases that already existed at the time.
""",
        """Use `status` to inspect scope, schedule policy, operation timeout, last trusted check, adoption time, and the last release successfully applied by this updater. `version=unmanaged` means the current registration has only an adoption baseline or was installed outside the bridge's active-state history; it does not mean the Skill is invalid. The first trusted `check` records the baseline without applying pre-existing releases. An explicit first `apply` is the consent boundary that may adopt the highest eligible verified release and create managed state; scheduled invocations remain observation-only until then.
""",
        "docs: status guidance",
    )
    path.write_text(text)


for updater in [Path("bin/traceknot-skills-update"), Path("skill/bin/traceknot-skills-update")]:
    update_updater(updater)
update_tests(Path("tests/skills-updater-smoke.sh"))
update_docs(Path("docs/automatic-updates.md"))

if Path("bin/traceknot-skills-update").read_bytes() != Path("skill/bin/traceknot-skills-update").read_bytes():
    raise SystemExit("updater mirror drift after patch")

print("PR #68 review patch applied")
